@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul

echo.
echo ============================================================
echo   EGIS Smart Tools — Deploy Script
echo   Navisworks Manage 2026
echo ============================================================
echo.

:: ── Destination: uses %APPDATA% which resolves to current user ──────────────
set "PLUGIN_NAME=EGISSmartTools"
set "DEPLOY_ROOT=%APPDATA%\Autodesk\Navisworks Manage 2026\Plugins\%PLUGIN_NAME%"
set "DEPLOY_IMAGES=%DEPLOY_ROOT%\Images"
set "DEPLOY_ENUS=%DEPLOY_ROOT%\en-US"
set "DEPLOY_ENUS_IMAGES=%DEPLOY_ROOT%\en-US\Images"

:: ── Source: folder where this .bat lives (must be next to EGISSmartTools.dll) 
set "SOURCE_DIR=%~dp0"

echo [1/5] Checking source files...
if not exist "%SOURCE_DIR%EGISSmartTools.dll" (
    echo.
    echo ERROR: EGISSmartTools.dll not found in:
    echo        %SOURCE_DIR%
    echo.
    echo Place this .bat file in the same folder as EGISSmartTools.dll
    echo and run again.
    pause
    exit /b 1
)
echo       OK — Source: %SOURCE_DIR%

echo.
echo [2/5] Creating plugin folders...
if not exist "%DEPLOY_ROOT%"         mkdir "%DEPLOY_ROOT%"
if not exist "%DEPLOY_IMAGES%"       mkdir "%DEPLOY_IMAGES%"
if not exist "%DEPLOY_ENUS%"         mkdir "%DEPLOY_ENUS%"
if not exist "%DEPLOY_ENUS_IMAGES%"  mkdir "%DEPLOY_ENUS_IMAGES%"
echo       OK — Target: %DEPLOY_ROOT%

echo.
echo [3/5] Copying main DLL and dependencies...

:: Main DLL
copy /Y "%SOURCE_DIR%EGISSmartTools.dll" "%DEPLOY_ROOT%\" >nul
echo       EGISSmartTools.dll

:: WebView2 runtime (Street View panel)
for %%F in (
    "Microsoft.Web.WebView2.Core.dll"
    "Microsoft.Web.WebView2.WinForms.dll"
    "WebView2Loader.dll"
) do (
    if exist "%SOURCE_DIR%%%~F" (
        copy /Y "%SOURCE_DIR%%%~F" "%DEPLOY_ROOT%\" >nul
        echo       %%~F
    )
)

:: OpenXML (Property Importer)
if exist "%SOURCE_DIR%DocumentFormat.OpenXml.dll" (
    copy /Y "%SOURCE_DIR%DocumentFormat.OpenXml.dll" "%DEPLOY_ROOT%\" >nul
    echo       DocumentFormat.OpenXml.dll
)

echo.
echo [4/5] Copying XAML and icons...

:: RibbonLayout.xaml — root AND en-US (Navisworks requires both)
if exist "%SOURCE_DIR%RibbonLayout.xaml" (
    copy /Y "%SOURCE_DIR%RibbonLayout.xaml" "%DEPLOY_ROOT%\" >nul
    copy /Y "%SOURCE_DIR%RibbonLayout.xaml" "%DEPLOY_ENUS%\" >nul
    echo       RibbonLayout.xaml  ^(root + en-US^)
) else (
    echo       WARNING: RibbonLayout.xaml not found — ribbon may not load
)

:: Icons — Images\ and en-US\Images\
set "ICON_COUNT=0"
if exist "%SOURCE_DIR%Images\" (
    for %%F in ("%SOURCE_DIR%Images\*.png") do (
        copy /Y "%%F" "%DEPLOY_IMAGES%\" >nul
        copy /Y "%%F" "%DEPLOY_ENUS_IMAGES%\" >nul
        set /a ICON_COUNT+=1
    )
)
echo       Icons: !ICON_COUNT! PNG files  ^(Images\ + en-US\Images\^)

echo.
echo [5/5] Verifying install...
set "OK=1"
for %%F in (
    "EGISSmartTools.dll"
    "RibbonLayout.xaml"
) do (
    if not exist "%DEPLOY_ROOT%\%%~F" (
        echo       MISSING: %%~F
        set "OK=0"
    )
)
if "!OK!"=="1" (
    echo       All required files present.
)

echo.
echo ============================================================
echo   Deploy complete!
echo   User   : %USERNAME%
echo   Target : %DEPLOY_ROOT%
echo.
echo   Please RESTART Navisworks Manage 2026 to load the plugin.
echo ============================================================
echo.
pause
